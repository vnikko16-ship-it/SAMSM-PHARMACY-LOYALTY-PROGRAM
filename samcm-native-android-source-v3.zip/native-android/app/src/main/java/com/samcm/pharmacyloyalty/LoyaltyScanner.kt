package com.samcm.pharmacyloyalty

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.barcode.BarcodeScanner
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.common.InputImage

@Composable
fun LoyaltyCardScanner(onScanned: (String) -> Unit, onDismiss: () -> Unit) {
  val context = LocalContext.current
  var hasPermission by remember { mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) }
  val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted -> hasPermission = granted }

  Column(
    modifier = Modifier.fillMaxSize().background(Color(0xFFFFF8F8)).padding(20.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp),
  ) {
    Text("Scan loyalty card", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = Color(0xFF4A1118))
    Text("Position the QR or barcode inside the camera view. The customer ID will be filled automatically.", color = Color(0xFF6E3540))
    if (hasPermission) {
      NativeCameraScanner(onScanned = onScanned)
    } else {
      Column(modifier = Modifier.fillMaxWidth().height(420.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Text("Camera permission is required to scan loyalty cards.")
        Spacer(Modifier.height(12.dp))
        Button(onClick = { permissionLauncher.launch(Manifest.permission.CAMERA) }) { Text("Allow camera") }
      }
    }
    OutlinedButton(onClick = onDismiss, modifier = Modifier.fillMaxWidth()) { Text("Use manual customer ID instead") }
  }
}

@Composable
private fun NativeCameraScanner(onScanned: (String) -> Unit) {
  val context = LocalContext.current
  val lifecycleOwner = LocalLifecycleOwner.current
  val cameraProviderFuture = remember(context) { ProcessCameraProvider.getInstance(context) }
  val scanner = remember { loyaltyBarcodeScanner() }
  var captured by remember { mutableStateOf(false) }

  DisposableEffect(cameraProviderFuture, scanner) {
    onDispose {
      scanner.close()
      runCatching { cameraProviderFuture.get().unbindAll() }
    }
  }

  AndroidView(
    modifier = Modifier.fillMaxWidth().height(420.dp),
    factory = { viewContext ->
      PreviewView(viewContext).also { previewView ->
        cameraProviderFuture.addListener({
          val provider = cameraProviderFuture.get()
          val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
          val analysis = ImageAnalysis.Builder()
            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
            .build()
          analysis.setAnalyzer(ContextCompat.getMainExecutor(viewContext)) { imageProxy ->
            val mediaImage = imageProxy.image
            if (mediaImage == null || captured) {
              imageProxy.close()
            } else {
              val image = InputImage.fromMediaImage(mediaImage, imageProxy.imageInfo.rotationDegrees)
              scanner.process(image)
                .addOnSuccessListener { codes ->
                  val decoded = codes.firstOrNull { !it.rawValue.isNullOrBlank() }?.rawValue?.trim()
                  if (!captured && !decoded.isNullOrBlank()) {
                    captured = true
                    onScanned(decoded.uppercase())
                  }
                }
                .addOnCompleteListener { imageProxy.close() }
            }
          }
          provider.unbindAll()
          provider.bindToLifecycle(lifecycleOwner, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
        }, ContextCompat.getMainExecutor(viewContext))
      }
    },
  )
}

private fun loyaltyBarcodeScanner(): BarcodeScanner {
  val options = BarcodeScannerOptions.Builder()
    .setBarcodeFormats(Barcode.FORMAT_QR_CODE, Barcode.FORMAT_CODE_128, Barcode.FORMAT_CODE_39)
    .build()
  return BarcodeScanning.getClient(options)
}
