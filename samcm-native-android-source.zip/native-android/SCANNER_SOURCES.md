# Native Barcode Scanner References

The Android client uses CameraX with Google ML Kit's bundled barcode-scanning model. The bundled model is immediately available inside the installed app, while the dynamic model relies on a Google Play Services download. The scanner is restricted to QR Code, Code 128, and Code 39 formats because SAMCM loyalty cards contain customer identifiers in QR and Code 39/128 representations. [1]

CameraX `ImageAnalysis` supplies an `ImageProxy`; the implementation converts its `media.Image` and rotation value to an ML Kit `InputImage`, processes it with a `BarcodeScanner`, and closes every `ImageProxy` after analysis. This is the standard native Android approach for live scanning. [1]

The implementation uses an analysis backpressure strategy that keeps only the latest frame. This avoids queueing stale camera frames while the barcode processor is working. Android also documents `MlKitAnalyzer` as a CameraX integration option for coordinate-aware overlays. [2]

## References

[1] [Google ML Kit: Scan barcodes with ML Kit on Android](https://developers.google.com/ml-kit/vision/barcode-scanning/android)

[2] [Android Developers: ML Kit Analyzer](https://developer.android.com/media/camera/camerax/mlkitanalyzer)
