# SAMCM Pharmacy Loyalty Program — Native Android Client

This folder contains a **bare Kotlin/Jetpack Compose Android project**. It does not use Expo. The client opens a server-validated staff session, connects to the managed central loyalty database, refreshes shared records every 15 seconds, and supports customer registration, purchase earning, and point redemption from any connected location.

The installable APK stores its shared server address during first-time staff setup, so it does not need to be rebuilt when the server URL is entered. Publish the SAMCM server first, then enter the resulting HTTPS address once on each device before entering the shared PIN. To produce a local APK in Android Studio, open this `native-android` folder, allow Gradle to synchronize, and use **Build → Generate App Bundles or APKs → Generate APKs**.

The app never stores the shared PIN. It keeps only a time-limited server session token for each device. The server is responsible for enforcing customer IDs, invoice uniqueness, and available-points checks.
