plugins {
  id("com.android.application")
  id("org.jetbrains.kotlin.android")
  id("org.jetbrains.kotlin.plugin.compose")
}

android {
  namespace = "com.samcm.pharmacyloyalty"
  compileSdk = 35

  defaultConfig {
    applicationId = "com.samcm.pharmacyloyalty"
    minSdk = 26
    targetSdk = 35
    versionCode = 1
    versionName = "1.0.0"
    buildConfigField("String", "SAMCM_API_BASE_URL", "\"https://REPLACE_WITH_PUBLISHED_SAMCM_SERVER\"")
  }

  buildFeatures {
    buildConfig = true
    compose = true
  }
}

dependencies {
  implementation(platform("androidx.compose:compose-bom:2024.12.01"))
  implementation("androidx.activity:activity-compose:1.10.0")
  implementation("androidx.compose.ui:ui")
  implementation("androidx.compose.ui:ui-tooling-preview")
  implementation("androidx.compose.material3:material3")
  implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
  implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
  implementation("androidx.camera:camera-core:1.4.1")
  implementation("androidx.camera:camera-camera2:1.4.1")
  implementation("androidx.camera:camera-lifecycle:1.4.1")
  implementation("androidx.camera:camera-view:1.4.1")
  implementation("com.google.mlkit:barcode-scanning:17.3.0")
  debugImplementation("androidx.compose.ui:ui-tooling")
}
