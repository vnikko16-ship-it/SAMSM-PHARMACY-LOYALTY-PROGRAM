package com.samcm.pharmacyloyalty

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import androidx.lifecycle.viewModelScope
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

private val SamcmRed = Color(0xFFB5121B)
private val SamcmBurgundy = Color(0xFF4A1118)
private val SamcmRose = Color(0xFFFCE9EB)
private val SamcmPaper = Color(0xFFFFF8F8)

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    setContent {
      MaterialTheme(colorScheme = MaterialTheme.colorScheme.copy(primary = SamcmRed, background = SamcmPaper, onBackground = SamcmBurgundy)) {
        SamcmLoyaltyApp(applicationContext)
      }
    }
  }
}

data class RemoteCustomer(val customerId: String, val fullName: String, val mobile: String, val pointsBalance: Int, val active: Boolean)
data class RemoteTransaction(val id: String, val customerId: String, val type: String, val pointsDelta: Int, val balanceAfter: Int)
data class LoyaltyUiState(
  val sessionToken: String? = null,
  val serverUrl: String = "",
  val customers: List<RemoteCustomer> = emptyList(),
  val transactions: List<RemoteTransaction> = emptyList(),
  val loading: Boolean = true,
  val message: String? = null,
)

class LoyaltyViewModel : ViewModel() {
  private val _state = MutableStateFlow(LoyaltyUiState())
  val state = _state.asStateFlow()
  private lateinit var store: android.content.SharedPreferences
  private lateinit var deviceId: String

  fun initialize(context: Context) {
    if (::store.isInitialized) return
    store = context.getSharedPreferences("samcm_loyalty", Context.MODE_PRIVATE)
    deviceId = store.getString("device_id", null) ?: UUID.randomUUID().toString().also { store.edit().putString("device_id", it).apply() }
    val savedServerUrl = store.getString("server_url", null) ?: BuildConfig.SAMCM_API_BASE_URL.takeUnless { it.contains("REPLACE_WITH") }.orEmpty()
    SamcmApi.configure(savedServerUrl)
    val token = store.getString("staff_session", null)
    _state.value = _state.value.copy(sessionToken = token, serverUrl = savedServerUrl, loading = token != null)
    if (token != null) refresh()
    else _state.value = _state.value.copy(loading = false)
  }

  fun openSession(pin: String, serverUrl: String) = viewModelScope.launch(Dispatchers.IO) {
    val normalizedUrl = serverUrl.trim().trimEnd('/')
    if (!normalizedUrl.startsWith("https://")) {
      _state.value = _state.value.copy(message = "Enter the secure HTTPS server address supplied after the SAMCM server is published.")
      return@launch
    }
    SamcmApi.configure(normalizedUrl)
    store.edit().putString("server_url", normalizedUrl).apply()
    _state.value = _state.value.copy(loading = true, message = null)
    runCatching { SamcmApi.openSession(pin, deviceId) }.onSuccess { token ->
      store.edit().putString("staff_session", token).apply()
      _state.value = _state.value.copy(sessionToken = token, serverUrl = normalizedUrl)
      refresh()
    }.onFailure { _state.value = _state.value.copy(loading = false, message = it.message ?: "Unable to open staff session.") }
  }

  fun refresh(showSpinner: Boolean = true) = viewModelScope.launch(Dispatchers.IO) {
    val token = _state.value.sessionToken ?: return@launch
    if (showSpinner) _state.value = _state.value.copy(loading = true)
    runCatching { SamcmApi.snapshot(token, deviceId) }.onSuccess { snapshot ->
      _state.value = _state.value.copy(loading = false, customers = snapshot.first, transactions = snapshot.second, message = null)
    }.onFailure {
      val expired = it.message?.contains("session", ignoreCase = true) == true
      if (expired) store.edit().remove("staff_session").apply()
      _state.value = _state.value.copy(loading = false, sessionToken = if (expired) null else token, message = it.message ?: "Unable to refresh shared data.")
    }
  }

  fun addCustomer(name: String, mobile: String) = viewModelScope.launch(Dispatchers.IO) {
    val token = _state.value.sessionToken ?: return@launch
    _state.value = _state.value.copy(loading = true)
    runCatching { SamcmApi.addCustomer(token, deviceId, name, mobile) }.onSuccess { refresh() }.onFailure { _state.value = _state.value.copy(loading = false, message = it.message) }
  }

  fun addPurchase(customerId: String, invoice: String, amount: String) = viewModelScope.launch(Dispatchers.IO) {
    val token = _state.value.sessionToken ?: return@launch
    _state.value = _state.value.copy(loading = true)
    runCatching { SamcmApi.addPurchase(token, deviceId, customerId, invoice, amount.toDouble()) }.onSuccess { refresh() }.onFailure { _state.value = _state.value.copy(loading = false, message = it.message) }
  }

  fun redeem(customerId: String, points: String) = viewModelScope.launch(Dispatchers.IO) {
    val token = _state.value.sessionToken ?: return@launch
    _state.value = _state.value.copy(loading = true)
    runCatching { SamcmApi.redeem(token, deviceId, customerId, points.toInt()) }.onSuccess { refresh() }.onFailure { _state.value = _state.value.copy(loading = false, message = it.message) }
  }
}

@Composable
private fun SamcmLoyaltyApp(context: Context, model: LoyaltyViewModel = viewModel()) {
  model.initialize(context)
  val state by model.state.collectAsStateWithLifecycle()
  LaunchedEffect(state.sessionToken) {
    while (state.sessionToken != null && isActive) { delay(15_000); model.refresh(false) }
  }
  if (state.sessionToken == null) StaffPinScreen(state, model) else SharedDashboard(state, model)
}

@Composable
private fun StaffPinScreen(state: LoyaltyUiState, model: LoyaltyViewModel) {
  var pin by remember { mutableStateOf("") }
  var serverUrl by remember(state.serverUrl) { mutableStateOf(state.serverUrl) }
  Column(modifier = Modifier.fillMaxSize().background(SamcmPaper).padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
    Text("SAMCM Pharmacy", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = SamcmBurgundy)
    Text("Loyalty Program", color = SamcmRed)
    Spacer(Modifier.height(28.dp))
    Card(colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.fillMaxWidth()) {
      Column(modifier = Modifier.padding(20.dp)) {
        Text("Staff access", fontWeight = FontWeight.Bold, color = SamcmBurgundy)
        Text("Enter the shared staff PIN to connect to the live loyalty records.", style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(value = serverUrl, onValueChange = { serverUrl = it }, label = { Text("SAMCM server address") }, placeholder = { Text("https://your-samcm-server") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(value = pin, onValueChange = { pin = it }, label = { Text("Staff PIN") }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(12.dp))
        Button(onClick = { model.openSession(pin, serverUrl) }, enabled = pin.length >= 4 && serverUrl.startsWith("https://") && !state.loading, modifier = Modifier.fillMaxWidth()) { Text("Connect to shared system") }
      }
    }
    if (state.loading) { Spacer(Modifier.height(18.dp)); CircularProgressIndicator(color = SamcmRed) }
    state.message?.let { Text(it, color = SamcmRed, modifier = Modifier.padding(top = 16.dp)) }
  }
}

@Composable
private fun SharedDashboard(state: LoyaltyUiState, model: LoyaltyViewModel) {
  var section by remember { mutableStateOf("Overview") }
  Column(modifier = Modifier.fillMaxSize().background(SamcmPaper)) {
    Row(modifier = Modifier.fillMaxWidth().background(SamcmBurgundy).padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
      Column(modifier = Modifier.weight(1f)) { Text("SAMCM Loyalty", color = Color.White, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold); Text("Live multi-location records", color = SamcmRose, style = MaterialTheme.typography.bodySmall) }
      TextButton(onClick = { model.refresh() }) { Text("Refresh", color = Color.White) }
    }
    Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
      listOf("Overview", "Customers", "Operations").forEach { item -> Text(item, color = if (section == item) SamcmRed else SamcmBurgundy, fontWeight = if (section == item) FontWeight.Bold else FontWeight.Normal, modifier = Modifier.clickable { section = item }.padding(8.dp)) }
    }
    if (state.loading) { Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) { CircularProgressIndicator(color = SamcmRed) } }
    else when (section) {
      "Customers" -> CustomerScreen(state, model)
      "Operations" -> OperationsScreen(state, model)
      else -> OverviewScreen(state)
    }
    state.message?.let { Text(it, color = SamcmRed, modifier = Modifier.padding(16.dp)) }
  }
}

@Composable
private fun OverviewScreen(state: LoyaltyUiState) {
  val active = state.customers.count { it.active }
  val points = state.customers.sumOf { it.pointsBalance }
  Column(modifier = Modifier.padding(20.dp)) {
    Text("Shared loyalty overview", style = MaterialTheme.typography.titleLarge, color = SamcmBurgundy, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(12.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) { Metric("Active customers", active.toString(), Modifier.weight(1f)); Metric("Outstanding points", points.toString(), Modifier.weight(1f)) }
    Spacer(Modifier.height(12.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) { Metric("Loyalty records", state.transactions.size.toString(), Modifier.weight(1f)); Metric("Live refresh", "15 sec", Modifier.weight(1f)) }
    Spacer(Modifier.height(20.dp)); Text("Every entry is saved to the shared online database and becomes visible to connected locations after the next refresh.", style = MaterialTheme.typography.bodySmall)
  }
}

@Composable
private fun Metric(label: String, value: String, modifier: Modifier) { Card(modifier = modifier, colors = CardDefaults.cardColors(containerColor = SamcmRose)) { Column(modifier = Modifier.padding(14.dp)) { Text(label, style = MaterialTheme.typography.bodySmall, color = SamcmBurgundy); Text(value, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = SamcmBurgundy) } } }

@Composable
private fun CustomerScreen(state: LoyaltyUiState, model: LoyaltyViewModel) {
  var name by remember { mutableStateOf("") }; var mobile by remember { mutableStateOf("") }
  LazyColumn(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
    item { Text("Customers", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = SamcmBurgundy); Spacer(Modifier.height(8.dp)); OutlinedTextField(name, { name = it }, label = { Text("Customer name") }, modifier = Modifier.fillMaxWidth()); OutlinedTextField(mobile, { mobile = it }, label = { Text("Mobile number") }, modifier = Modifier.fillMaxWidth()); Button(onClick = { model.addCustomer(name, mobile); name = ""; mobile = "" }, enabled = name.isNotBlank() && mobile.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("Add customer") }; Spacer(Modifier.height(12.dp)) }
    items(state.customers) { customer -> Card(colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.fillMaxWidth()) { Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Column(modifier = Modifier.weight(1f)) { Text(customer.fullName, fontWeight = FontWeight.Bold, color = SamcmBurgundy); Text("${customer.customerId} · ${customer.mobile}", style = MaterialTheme.typography.bodySmall) }; Text("${customer.pointsBalance} pts", color = SamcmRed, fontWeight = FontWeight.Bold) } } }
  }
}

@Composable
private fun OperationsScreen(state: LoyaltyUiState, model: LoyaltyViewModel) {
  var customerId by remember { mutableStateOf("") }; var invoice by remember { mutableStateOf("") }; var amount by remember { mutableStateOf("") }; var points by remember { mutableStateOf("") }; var scannerOpen by remember { mutableStateOf(false) }
  if (scannerOpen) {
    LoyaltyCardScanner(
      onScanned = { code -> customerId = code; scannerOpen = false },
      onDismiss = { scannerOpen = false },
    )
    return
  }
  Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
    Text("Record loyalty activity", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = SamcmBurgundy)
    OutlinedButton(onClick = { scannerOpen = true }, modifier = Modifier.fillMaxWidth()) { Text("Scan loyalty card with camera") }
    OutlinedTextField(customerId, { customerId = it.uppercase() }, label = { Text("Customer ID, e.g. TGP-000001") }, modifier = Modifier.fillMaxWidth())
    OutlinedTextField(invoice, { invoice = it.uppercase() }, label = { Text("Invoice number") }, modifier = Modifier.fillMaxWidth())
    OutlinedTextField(amount, { amount = it }, label = { Text("Purchase amount") }, modifier = Modifier.fillMaxWidth())
    Button(onClick = { model.addPurchase(customerId, invoice, amount); invoice = ""; amount = "" }, enabled = customerId.isNotBlank() && invoice.isNotBlank() && amount.toDoubleOrNull() != null, modifier = Modifier.fillMaxWidth()) { Text("Save purchase and points") }
    Spacer(Modifier.height(8.dp)); OutlinedTextField(points, { points = it }, label = { Text("Points to redeem") }, modifier = Modifier.fillMaxWidth())
    OutlinedButton(onClick = { model.redeem(customerId, points); points = "" }, enabled = customerId.isNotBlank() && points.toIntOrNull() != null, modifier = Modifier.fillMaxWidth()) { Text("Redeem points") }
  }
}

private object SamcmApi {
  private var root = ""
  fun configure(baseUrl: String) { root = baseUrl.trimEnd('/') }
  fun openSession(pin: String, deviceId: String): String = JSONObject(request("POST", "/api/loyalty/session", null, JSONObject().put("pin", pin).put("deviceId", deviceId))).getString("sessionToken")
  fun snapshot(token: String, deviceId: String): Pair<List<RemoteCustomer>, List<RemoteTransaction>> {
    val payload = JSONObject(request("GET", "/api/loyalty/snapshot", token, null, deviceId))
    return parseCustomers(payload.optJSONArray("customers") ?: JSONArray()) to parseTransactions(payload.optJSONArray("transactions") ?: JSONArray())
  }
  fun addCustomer(token: String, deviceId: String, name: String, mobile: String) { request("POST", "/api/loyalty/customers", token, JSONObject().put("name", name).put("mobile", mobile), deviceId) }
  fun addPurchase(token: String, deviceId: String, customerId: String, invoice: String, amount: Double) { request("POST", "/api/loyalty/purchases", token, JSONObject().put("customerId", customerId).put("invoiceNumber", invoice).put("amount", amount), deviceId) }
  fun redeem(token: String, deviceId: String, customerId: String, points: Int) { request("POST", "/api/loyalty/redemptions", token, JSONObject().put("customerId", customerId).put("points", points), deviceId) }
  private fun request(method: String, path: String, token: String?, body: JSONObject?, deviceId: String? = null): String {
    check(root.startsWith("https://")) { "Enter the secure SAMCM server address before connecting." }
    val connection = URL(root + path).openConnection() as HttpURLConnection
    connection.requestMethod = method; connection.setRequestProperty("Content-Type", "application/json"); if (token != null) connection.setRequestProperty("x-samcm-session", token); if (deviceId != null) connection.setRequestProperty("x-samcm-device", deviceId)
    if (body != null) { connection.doOutput = true; connection.outputStream.use { it.write(body.toString().toByteArray()) } }
    val content = (if (connection.responseCode in 200..299) connection.inputStream else connection.errorStream).bufferedReader().use { it.readText() }
    if (connection.responseCode !in 200..299) throw IllegalStateException(JSONObject(content).optString("message", "Server request failed."))
    return content
  }
  private fun parseCustomers(values: JSONArray) = List(values.length()) { index -> values.getJSONObject(index).let { RemoteCustomer(it.optString("customerId"), it.optString("fullName"), it.optString("mobile"), it.optInt("pointsBalance"), it.optBoolean("active", true)) } }
  private fun parseTransactions(values: JSONArray) = List(values.length()) { index -> values.getJSONObject(index).let { RemoteTransaction(it.optString("id"), it.optString("customerId"), it.optString("type"), it.optInt("pointsDelta"), it.optInt("balanceAfter")) } }
}
